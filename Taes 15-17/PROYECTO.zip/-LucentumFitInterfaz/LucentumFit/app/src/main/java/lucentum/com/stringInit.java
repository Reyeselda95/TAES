package lucentum.com;

/**
 * Created by LeoRodMrez on 19/5/16.
 */
public class stringInit {
    public static String getS() {
        return s;
    }

    public static void setS(String s) {
        stringInit.s = s;
    }

    private static String s;
}
