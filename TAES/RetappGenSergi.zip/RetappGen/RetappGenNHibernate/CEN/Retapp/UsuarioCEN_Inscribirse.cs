
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using RetappGenNHibernate.EN.Retapp;
using RetappGenNHibernate.CAD.Retapp;

namespace RetappGenNHibernate.CEN.Retapp
{
public partial class UsuarioCEN
{
public void Inscribirse (int p_oid)
{
        /*PROTECTED REGION ID(RetappGenNHibernate.CEN.Retapp_Usuario_Inscribirse) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Inscribirse() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
