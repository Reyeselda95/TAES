
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using RetappGenNHibernate.EN.Retapp;
using RetappGenNHibernate.CAD.Retapp;

namespace RetappGenNHibernate.CEN.Retapp
{
public partial class ParticipacionCEN
{
public void Ganar ()
{
        /*PROTECTED REGION ID(RetappGenNHibernate.CEN.Retapp_Participacion_Ganar) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Ganar() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
