
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using RetappGenNHibernate.EN.Retapp;
using RetappGenNHibernate.CAD.Retapp;

namespace RetappGenNHibernate.CEN.Retapp
{
public partial class AdminCEN
{
public bool Validar (string usr, string pass)
{
        /*PROTECTED REGION ID(RetappGenNHibernate.CEN.Retapp_Admin_Validar) ENABLED START*/

        // Write here your custom code...

        

        //throw new NotImplementedException ("Method Validar() not yet implemented.");
        
        /*PROTECTED REGION END*/
}
}
}
