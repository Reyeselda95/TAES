﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using WebApplication4.Clases;
using RetappGenNHibernate.CAD.Retapp;
using RetappGenNHibernate.EN.Retapp;
using System.Data.SqlClient;

namespace WebApplication4
{
    /// <summary>
    /// Descripción breve de WebService2
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService2 : System.Web.Services.WebService
    {
        

        //Muestra todos los concursos
        [WebMethod]
        public Concurso[] ListadoConcursos()
        {
            //Concurso[] c = new Concurso[];
            //SqlConnection con = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=RetappGenNHibernate;Integrated Security=True");
            SqlConnection con = new SqlConnection(@"Server=(local); database=RetappGenNHibernate; integrated security=yes");

            con.Open();

            string sql = "SELECT idConcurso, FechaFin, Aprobado, Finalizado, Campaña, Cuerpo, Premios, Reto, Pos, FechaInicio FROM RetappGenNHibernate.dbo.Concurso";

            SqlCommand cmd = new SqlCommand(sql, con);

            SqlDataReader reader = cmd.ExecuteReader();

            List<Concurso> lista = new List<Concurso>();

            while (reader.Read())
            {
                lista.Add(new Concurso(reader.GetInt32(0), reader.GetDateTime(1), reader.GetBoolean(2), reader.GetBoolean(3), reader.GetString(4), reader.GetString(5), reader.GetString(6), reader.GetString(7), reader.GetInt32(8), reader.GetDateTime(9)));
            }

            con.Close();
            //return lista;

            return lista.ToArray();

        }


        //
        [WebMethod]
        public Concurso[] ListadoConcursos1()
        {
            //Concurso[] c = new Concurso[];
            //SqlConnection con = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=RetappGenNHibernate;Integrated Security=True");
            SqlConnection con = new SqlConnection(@"Server=(local); database=RetappGenNHibernate; integrated security=yes");

            con.Open();

            string sql = "SELECT Campaña, Reto FROM RetappGenNHibernate.dbo.Concurso";

            SqlCommand cmd = new SqlCommand(sql, con);

            SqlDataReader reader = cmd.ExecuteReader();

            List<Concurso> lista = new List<Concurso>();

            while (reader.Read())
            {
                lista.Add(new Concurso(reader.GetString(0), reader.GetString(1)));
            }

            con.Close();
            //return lista;

            return lista.ToArray();


        }


        //Metodo para inscribirse en un concurso
        [WebMethod]
        public Resultado inscribirse(int idUsuario, int idConcurso)
        {

            Resultado res = new Resultado();
            res.result = true;
            res.msg = "Inscripción realizada con éxito.";



            SqlConnection con = new SqlConnection(@"Server=(local); database=RetappGenNHibernate; integrated security=yes");
            con.Open();

            string sql = "SELECT * FROM RetappGenNHibernate.dbo.Participacion where FK_idConcurso_idConcurso_0 = " + idConcurso + " and FK_idUsuario_idUsuario = " + idUsuario + ";";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                res.result = false;
                res.msg = "El usuario ya está inscrito en este concurso.";

            }

            else
            {

                ConcursoCAD concursoCAD = new ConcursoCAD();
                ConcursoEN concursoEN = concursoCAD.ReadOID(idConcurso);
                UsuarioCAD usuarioCAD = new UsuarioCAD();
                UsuarioEN usuarioEN = usuarioCAD.ReadOID(idUsuario);
                if (concursoEN == null || usuarioEN == null)
                {
                    res.result = false;
                    res.msg = "El usuario y/o el concurso no existen.";
                }
                else
                {

                    ParticipacionCAD participacionCAD = new ParticipacionCAD();
                    ParticipacionEN participacionEN = new ParticipacionEN();
                    participacionEN.Fecha = DateTime.Now;
                    participacionEN.Valor = 0;
                    participacionEN.Prueba = "";
                    participacionEN.Votos = 0;
                    participacionEN.Reportes = 0;
                    participacionEN.Concurso = concursoEN;
                    participacionEN.Usuario = usuarioEN;
                    participacionCAD.New_(participacionEN);

                }

            }
            con.Close();

            return res;

        }


        //Muestra en que concursos esta inscrito un usuario y los votos y la posicion
        [WebMethod]
        public ParticipacionUsuario[] getParticipacionesUsuario(int idUusario)
        {

            List<ParticipacionUsuario> lista = new List<ParticipacionUsuario>();
            ParticipacionCAD participacionCAD = new ParticipacionCAD();
            List<ParticipacionEN> participaciones = new List<ParticipacionEN>(participacionCAD.ReadAll(0, 0));
            participaciones = participaciones.Where(p => p.Usuario.Id == idUusario).ToList<ParticipacionEN>();

            foreach (ParticipacionEN pEN in participaciones)
            {
                lista.Add(new ParticipacionUsuario(pEN));
            }

            return lista.ToArray();

        }

        // Devuelve el concurso que se le pasa por id
        [WebMethod]
        public Concurso getConcurso(int id)
        {
            ConcursoCAD concursoCAD = new ConcursoCAD();
            return new Concurso(concursoCAD.ReadOID(id));

        }


        //Metodo cuando se le da a votar un reto, si se considera superado
        [WebMethod]
        public Resultado votar(int idParticipacion)
        {

            Resultado res = new Resultado();
            res.result = true;
            res.msg = "Voto realizado con éxito.";



            ParticipacionCAD participacionCAD = new ParticipacionCAD();
            ParticipacionEN participacionEN = participacionCAD.ReadOID(idParticipacion);

            if (participacionEN == null)
            {
                res.result = true;
                res.msg = "No se ha podido realizar la votación.";
            }
            else
            {
                participacionEN.Votos = participacionEN.Votos + 1;
                participacionCAD.Modify(participacionEN);

            }


            return res;

        }
        


        //Devuelve los datos del usuario pasandole su id
        [WebMethod]
        public Usuario UsuarioPerfil(int id)
        {

            UsuarioCAD usuarioCAD = new UsuarioCAD();
            return new Usuario(usuarioCAD.ReadOID(id));

        }

        [WebMethod]
        public string HelloWorld()
        {
            return "Hola a todos";
        }
    }
}
