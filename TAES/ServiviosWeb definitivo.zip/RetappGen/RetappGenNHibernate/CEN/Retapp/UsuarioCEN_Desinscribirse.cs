
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using RetappGenNHibernate.EN.Retapp;
using RetappGenNHibernate.CAD.Retapp;

namespace RetappGenNHibernate.CEN.Retapp
{
public partial class UsuarioCEN
{
public void Desinscribirse (int idPart)
{
        /*PROTECTED REGION ID(RetappGenNHibernate.CEN.Retapp_Usuario_Desinscribirse) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Desinscribirse() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
