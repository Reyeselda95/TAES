
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using RetappGenNHibernate.EN.Retapp;
using RetappGenNHibernate.CAD.Retapp;

namespace RetappGenNHibernate.CEN.Retapp
{
public partial class VictoriaCEN
{
public void Premios_usr (string usr)
{
        /*PROTECTED REGION ID(RetappGenNHibernate.CEN.Retapp_Victoria_Premios_usr) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Premios_usr() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
