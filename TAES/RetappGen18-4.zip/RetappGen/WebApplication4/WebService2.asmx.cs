﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using WebApplication4.Clases;
using RetappGenNHibernate.CAD.Retapp;
using RetappGenNHibernate.EN.Retapp;
using System.Data.SqlClient;

namespace WebApplication4
{
    /// <summary>
    /// Descripción breve de WebService2
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService2 : System.Web.Services.WebService
    {
        [WebMethod]
        public Concurso getConcurso(int id)
        {
            ConcursoCAD concursoCAD = new ConcursoCAD();
            return new Concurso(concursoCAD.ReadOID(id));

        }

        [WebMethod]
        public Concurso[] ListadoConcursos()
        {
            //Concurso[] c = new Concurso[];
            //SqlConnection con = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=RetappGenNHibernate;Integrated Security=True");
            SqlConnection con = new SqlConnection(@"Server=(local); database=RetappGenNHibernate; integrated security=yes");

            con.Open();

            string sql = "SELECT idConcurso, FechaFin, Aprobado, Finalizado, Campaña, Cuerpo, Premios, Reto, Pos, FechaInicio FROM RetappGenNHibernate.dbo.Concurso";

            SqlCommand cmd = new SqlCommand(sql, con);

            SqlDataReader reader = cmd.ExecuteReader();

            List<Concurso> lista = new List<Concurso>();

            while (reader.Read())
            {
                lista.Add(new Concurso(reader.GetInt32(0), reader.GetDateTime(1), reader.GetBoolean(2), reader.GetBoolean(3), reader.GetString(4), reader.GetString(5), reader.GetString(6), reader.GetString(7), reader.GetInt32(8), reader.GetDateTime(9)));
            }

            con.Close();
            //return lista;

            return lista.ToArray();


        }

        [WebMethod]
        public Concurso[] ListadoConcursos1()
        {
            //Concurso[] c = new Concurso[];
            //SqlConnection con = new SqlConnection(@"Data Source=localhost\SQLEXPRESS;Initial Catalog=RetappGenNHibernate;Integrated Security=True");
            SqlConnection con = new SqlConnection(@"Server=(local); database=RetappGenNHibernate; integrated security=yes");

            con.Open();

            string sql = "SELECT Campaña, Reto FROM RetappGenNHibernate.dbo.Concurso";

            SqlCommand cmd = new SqlCommand(sql, con);

            SqlDataReader reader = cmd.ExecuteReader();

            List<Concurso> lista = new List<Concurso>();

            while (reader.Read())
            {
                lista.Add(new Concurso(reader.GetString(0), reader.GetString(1)));
            }

            con.Close();
            //return lista;

            return lista.ToArray();


        }

        /*
        [WebMethod]
        public Concurso getConcursoPosicion(Usuario usu)
        {
            ConcursoCAD concursoCAD = new ConcursoCAD();
            Participacion par = new Participacion();
            par.
        }
        */
        
        /*
        [WebMethod]
        public void AumentarVotos(bool votado, ParticipacionEN p)
        {

            if (votado == true)
            {
                ParticipacionEN x = new ParticipacionEN();
                x = p;
                x.Votos++;

                ParticipacionCAD participacion = new ParticipacionCAD();
                participacion.Modify(x);

            }
            
            
            
            
            //usuarioCAD.Modify(usu.votos);

        }
        */

        
        /*
        [WebMethod]
        public String getConcursoNombre(int id)
        {
            ConcursoCAD concursoCAD = new ConcursoCAD();
            Concurso con = new Concurso(concursoCAD.ReadOID(id));
            return con.campanya;
        }
         * */


        [WebMethod]
        public Usuario getUsuario()
        {

            UsuarioCAD usuarioCAD = new UsuarioCAD();
            return new Usuario(usuarioCAD.ReadOID(1));

        }

        [WebMethod]
        public Usuario UsuarioPerfil(int id)
        {

            UsuarioCAD usuarioCAD = new UsuarioCAD();
            return new Usuario(usuarioCAD.ReadOID(id));

        }

        [WebMethod]
        public string HelloWorld()
        {
            return "Hola a todos";
        }
    }
}
